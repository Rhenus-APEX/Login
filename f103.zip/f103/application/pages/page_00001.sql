prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1760975605549696
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'CNL_WMS'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(1913799136567628)
,p_name=>'Order'
,p_alias=>'ORDER'
,p_step_title=>'Test app'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'PAUL'
,p_last_upd_yyyymmddhh24miss=>'20210831092400'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1757684868447631)
,p_plug_name=>'Order header'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1797704194567599)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>'select * from WMO_ORDER_HEADERS'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Order header'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(1757728744447632)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF:RTF:EMAIL'
,p_owner=>'PAUL'
,p_internal_uid=>1757728744447632
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1757802254447633)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1757983971447634)
,p_db_column_name=>'ACT_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Act Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758046578447635)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758113569447636)
,p_db_column_name=>'DB_LINK'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Db Link'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758269575447637)
,p_db_column_name=>'FROM_SITE_ID'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'From Site Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758317039447638)
,p_db_column_name=>'TO_SITE_ID'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'To Site Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758465817447639)
,p_db_column_name=>'CLIENT_ID'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Client Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758559544447640)
,p_db_column_name=>'ORDER_ID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Order Id'
,p_column_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::P2_ORD_ID:#ID#'
,p_column_linktext=>'#ORDER_ID#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758642160447641)
,p_db_column_name=>'OWNER_ID'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Owner Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758708643447642)
,p_db_column_name=>'ORDER_TYPE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Order Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758838468447643)
,p_db_column_name=>'WORK_ORDER_TYPE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Work Order Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1758943152447644)
,p_db_column_name=>'ORDER_STATUS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Order Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1759049333447645)
,p_db_column_name=>'MOVE_TASK_STATUS'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Move Task Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1759180529447646)
,p_db_column_name=>'PRIORITY'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Priority'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1759268641447647)
,p_db_column_name=>'REPACK'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Repack'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1759382921447648)
,p_db_column_name=>'REPACK_LOC_ID'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Repack Loc Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1759470071447649)
,p_db_column_name=>'SHIP_DOCK'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Ship Dock'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1759567311447650)
,p_db_column_name=>'WORK_GROUP'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Work Group'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1944544763708201)
,p_db_column_name=>'CONSIGNMENT'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Consignment'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1944609703708202)
,p_db_column_name=>'DELIVERY_POINT'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Delivery Point'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1944748131708203)
,p_db_column_name=>'LOAD_SEQUENCE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Load Sequence'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1944809209708204)
,p_db_column_name=>'CUSTOMER_ID'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Customer Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1944961859708205)
,p_db_column_name=>'ORDER_DATE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Order Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945091759708206)
,p_db_column_name=>'SHIP_BY_DATE'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ship By Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945129578708207)
,p_db_column_name=>'DELIVER_BY_DATE'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Deliver By Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945277691708208)
,p_db_column_name=>'SHIPPED_DATE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Shipped Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945311028708209)
,p_db_column_name=>'DELIVERED_DSTAMP'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Delivered Dstamp'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945480435708210)
,p_db_column_name=>'SIGNATORY'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Signatory'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945577704708211)
,p_db_column_name=>'PURCHASE_ORDER'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Purchase Order'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945671933708212)
,p_db_column_name=>'CARRIER_ID'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Carrier Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945711691708213)
,p_db_column_name=>'DISPATCH_METHOD'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Dispatch Method'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945855088708214)
,p_db_column_name=>'SERVICE_LEVEL'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Service Level'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1945955385708215)
,p_db_column_name=>'FASTEST_CARRIER'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Fastest Carrier'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946045027708216)
,p_db_column_name=>'CHEAPEST_CARRIER'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Cheapest Carrier'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946161131708217)
,p_db_column_name=>'INV_ADDRESS_ID'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Inv Address Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946252649708218)
,p_db_column_name=>'INV_CONTACT'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Inv Contact'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946307528708219)
,p_db_column_name=>'INV_CONTACT_PHONE'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Inv Contact Phone'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946478702708220)
,p_db_column_name=>'INV_CONTACT_MOBILE'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Inv Contact Mobile'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946578785708221)
,p_db_column_name=>'INV_CONTACT_FAX'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Inv Contact Fax'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946605073708222)
,p_db_column_name=>'INV_CONTACT_EMAIL'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Inv Contact Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946741786708223)
,p_db_column_name=>'INV_NAME'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Inv Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946811074708224)
,p_db_column_name=>'INV_ADDRESS1'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Inv Address1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1946972343708225)
,p_db_column_name=>'INV_ADDRESS2'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Inv Address2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947045428708226)
,p_db_column_name=>'INV_TOWN'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Inv Town'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947135098708227)
,p_db_column_name=>'INV_COUNTY'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Inv County'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947237427708228)
,p_db_column_name=>'INV_POSTCODE'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Inv Postcode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947319574708229)
,p_db_column_name=>'INV_COUNTRY'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Inv Country'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947455409708230)
,p_db_column_name=>'INSTRUCTIONS'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Instructions'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947537044708231)
,p_db_column_name=>'ORDER_VOLUME'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Order Volume'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947672193708232)
,p_db_column_name=>'ORDER_WEIGHT'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Order Weight'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947702713708233)
,p_db_column_name=>'CONTACT'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Contact'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947816586708234)
,p_db_column_name=>'CONTACT_PHONE'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Contact Phone'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1947944578708235)
,p_db_column_name=>'CONTACT_MOBILE'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Contact Mobile'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948003388708236)
,p_db_column_name=>'CONTACT_FAX'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Contact Fax'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948123464708237)
,p_db_column_name=>'CONTACT_EMAIL'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Contact Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948243226708238)
,p_db_column_name=>'NAME'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948374357708239)
,p_db_column_name=>'ADDRESS1'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Address1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948477948708240)
,p_db_column_name=>'ADDRESS2'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Address2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948585788708241)
,p_db_column_name=>'TOWN'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Town'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948692285708242)
,p_db_column_name=>'COUNTY'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'County'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948717349708243)
,p_db_column_name=>'POSTCODE'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Postcode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948889376708244)
,p_db_column_name=>'COUNTRY'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Country'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1948933668708245)
,p_db_column_name=>'ROUTE_PLANNED'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Route Planned'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949093735708246)
,p_db_column_name=>'UPLOADED'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Uploaded'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949193332708247)
,p_db_column_name=>'UPLOADED_WS2PC_ID'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Uploaded Ws2pc Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949293218708248)
,p_db_column_name=>'UPLOADED_DSTAMP'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Uploaded Dstamp'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949319870708249)
,p_db_column_name=>'UPLOADED_FILENAME'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Uploaded Filename'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949452030708250)
,p_db_column_name=>'UPLOADED_VVIEW'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Uploaded Vview'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949575620708301)
,p_db_column_name=>'UPLOADED_HEADER_KEY'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Uploaded Header Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949640173708302)
,p_db_column_name=>'PSFT_DMND_SRCE'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Psft Dmnd Srce'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949742792708303)
,p_db_column_name=>'PSFT_ORDER_ID'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Psft Order Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949857372708304)
,p_db_column_name=>'SITE_REPLEN'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Site Replen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1949971364708305)
,p_db_column_name=>'ORDER_ID_LINK'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Order Id Link'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950016504708306)
,p_db_column_name=>'ALLOCATION_RUN'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Allocation Run'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950171616708307)
,p_db_column_name=>'NO_SHIPMENT_EMAIL'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'No Shipment Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950219087708308)
,p_db_column_name=>'CID_NUMBER'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Cid Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950302685708309)
,p_db_column_name=>'SID_NUMBER'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Sid Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950447826708310)
,p_db_column_name=>'LOCATION_NUMBER'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Location Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950590822708311)
,p_db_column_name=>'FREIGHT_CHARGES'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Freight Charges'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950644343708312)
,p_db_column_name=>'DISALLOW_MERGE_RULES'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Disallow Merge Rules'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950717993708313)
,p_db_column_name=>'ORDER_SOURCE'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Order Source'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950814903708314)
,p_db_column_name=>'EXPORT'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Export'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1950952718708315)
,p_db_column_name=>'NUM_LINES'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Num Lines'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951020207708316)
,p_db_column_name=>'HIGHEST_LABEL'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Highest Label'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951159978708317)
,p_db_column_name=>'USER_DEF_TYPE_1'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'User Def Type 1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951214471708318)
,p_db_column_name=>'USER_DEF_TYPE_2'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'User Def Type 2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951362163708319)
,p_db_column_name=>'USER_DEF_TYPE_3'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'User Def Type 3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951426782708320)
,p_db_column_name=>'USER_DEF_TYPE_4'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'User Def Type 4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951532442708321)
,p_db_column_name=>'USER_DEF_TYPE_5'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'User Def Type 5'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951684328708322)
,p_db_column_name=>'USER_DEF_TYPE_6'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'User Def Type 6'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951786926708323)
,p_db_column_name=>'USER_DEF_TYPE_7'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'User Def Type 7'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951899887708324)
,p_db_column_name=>'USER_DEF_TYPE_8'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'User Def Type 8'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1951913440708325)
,p_db_column_name=>'USER_DEF_CHK_1'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'User Def Chk 1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952048578708326)
,p_db_column_name=>'USER_DEF_CHK_2'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'User Def Chk 2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952199087708327)
,p_db_column_name=>'USER_DEF_CHK_3'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'User Def Chk 3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952293289708328)
,p_db_column_name=>'USER_DEF_CHK_4'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'User Def Chk 4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952358552708329)
,p_db_column_name=>'USER_DEF_DATE_1'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'User Def Date 1'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952405095708330)
,p_db_column_name=>'USER_DEF_DATE_2'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'User Def Date 2'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952524516708331)
,p_db_column_name=>'USER_DEF_DATE_3'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'User Def Date 3'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952647389708332)
,p_db_column_name=>'USER_DEF_DATE_4'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'User Def Date 4'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952771991708333)
,p_db_column_name=>'USER_DEF_NUM_1'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'User Def Num 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952823543708334)
,p_db_column_name=>'USER_DEF_NUM_2'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'User Def Num 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1952924693708335)
,p_db_column_name=>'USER_DEF_NUM_3'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'User Def Num 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953059018708336)
,p_db_column_name=>'USER_DEF_NUM_4'
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>'User Def Num 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953115314708337)
,p_db_column_name=>'USER_DEF_NOTE_1'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'User Def Note 1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953265227708338)
,p_db_column_name=>'USER_DEF_NOTE_2'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'User Def Note 2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953341641708339)
,p_db_column_name=>'CE_REASON_CODE'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Ce Reason Code'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953469492708340)
,p_db_column_name=>'CE_REASON_NOTES'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Ce Reason Notes'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953582875708341)
,p_db_column_name=>'CE_ORDER_TYPE'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Ce Order Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953639637708342)
,p_db_column_name=>'CE_CUSTOMS_CUSTOMER'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Ce Customs Customer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953758917708343)
,p_db_column_name=>'CE_EXCISE_CUSTOMER'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Ce Excise Customer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953888428708344)
,p_db_column_name=>'CE_INSTRUCTIONS'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Ce Instructions'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1953905196708345)
,p_db_column_name=>'ROUTE_ID'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Route Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954057468708346)
,p_db_column_name=>'CROSS_DOCK_TO_SITE'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Cross Dock To Site'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954112682708347)
,p_db_column_name=>'WEB_SERVICE_ALLOC_IMMED'
,p_display_order=>1150
,p_column_identifier=>'DK'
,p_column_label=>'Web Service Alloc Immed'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954215075708348)
,p_db_column_name=>'WEB_SERVICE_ALLOC_CLEAN'
,p_display_order=>1160
,p_column_identifier=>'DL'
,p_column_label=>'Web Service Alloc Clean'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954399913708349)
,p_db_column_name=>'DISALLOW_SHORT_SHIP'
,p_display_order=>1170
,p_column_identifier=>'DM'
,p_column_label=>'Disallow Short Ship'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954472611708350)
,p_db_column_name=>'UPLOADED_CUSTOMS'
,p_display_order=>1180
,p_column_identifier=>'DN'
,p_column_label=>'Uploaded Customs'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954520178708301)
,p_db_column_name=>'UPLOADED_LABOR'
,p_display_order=>1190
,p_column_identifier=>'DO'
,p_column_label=>'Uploaded Labor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954644294708302)
,p_db_column_name=>'HUB_ADDRESS_ID'
,p_display_order=>1200
,p_column_identifier=>'DP'
,p_column_label=>'Hub Address Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954727868708303)
,p_db_column_name=>'HUB_CONTACT'
,p_display_order=>1210
,p_column_identifier=>'DQ'
,p_column_label=>'Hub Contact'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954859060708304)
,p_db_column_name=>'HUB_CONTACT_PHONE'
,p_display_order=>1220
,p_column_identifier=>'DR'
,p_column_label=>'Hub Contact Phone'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1954903861708305)
,p_db_column_name=>'HUB_CONTACT_MOBILE'
,p_display_order=>1230
,p_column_identifier=>'DS'
,p_column_label=>'Hub Contact Mobile'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955054826708306)
,p_db_column_name=>'HUB_CONTACT_FAX'
,p_display_order=>1240
,p_column_identifier=>'DT'
,p_column_label=>'Hub Contact Fax'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955195373708307)
,p_db_column_name=>'HUB_CONTACT_EMAIL'
,p_display_order=>1250
,p_column_identifier=>'DU'
,p_column_label=>'Hub Contact Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955257204708308)
,p_db_column_name=>'HUB_NAME'
,p_display_order=>1260
,p_column_identifier=>'DV'
,p_column_label=>'Hub Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955342103708309)
,p_db_column_name=>'HUB_ADDRESS1'
,p_display_order=>1270
,p_column_identifier=>'DW'
,p_column_label=>'Hub Address1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955416607708310)
,p_db_column_name=>'HUB_ADDRESS2'
,p_display_order=>1280
,p_column_identifier=>'DX'
,p_column_label=>'Hub Address2'
,p_column_type=>'STRING'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1760975605549696
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'CNL_WMS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955547546708311)
,p_db_column_name=>'HUB_TOWN'
,p_display_order=>1290
,p_column_identifier=>'DY'
,p_column_label=>'Hub Town'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955622544708312)
,p_db_column_name=>'HUB_COUNTY'
,p_display_order=>1300
,p_column_identifier=>'DZ'
,p_column_label=>'Hub County'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955722522708313)
,p_db_column_name=>'HUB_POSTCODE'
,p_display_order=>1310
,p_column_identifier=>'EA'
,p_column_label=>'Hub Postcode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955806350708314)
,p_db_column_name=>'HUB_COUNTRY'
,p_display_order=>1320
,p_column_identifier=>'EB'
,p_column_label=>'Hub Country'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1955941755708315)
,p_db_column_name=>'CANCEL_REASON_CODE'
,p_display_order=>1330
,p_column_identifier=>'EC'
,p_column_label=>'Cancel Reason Code'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956050453708316)
,p_db_column_name=>'STAGE_ROUTE_ID'
,p_display_order=>1340
,p_column_identifier=>'ED'
,p_column_label=>'Stage Route Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956121520708317)
,p_db_column_name=>'SINGLE_ORDER_SORTATION'
,p_display_order=>1350
,p_column_identifier=>'EE'
,p_column_label=>'Single Order Sortation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956245452708318)
,p_db_column_name=>'ARCHIVED'
,p_display_order=>1360
,p_column_identifier=>'EF'
,p_column_label=>'Archived'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956331332708319)
,p_db_column_name=>'CLOSURE_DATE'
,p_display_order=>1370
,p_column_identifier=>'EG'
,p_column_label=>'Closure Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956454098708320)
,p_db_column_name=>'ORDER_CLOSED'
,p_display_order=>1380
,p_column_identifier=>'EH'
,p_column_label=>'Order Closed'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956540807708321)
,p_db_column_name=>'TOTAL_REPACK_CONTAINERS'
,p_display_order=>1390
,p_column_identifier=>'EI'
,p_column_label=>'Total Repack Containers'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956688598708322)
,p_db_column_name=>'FORCE_SINGLE_CARRIER'
,p_display_order=>1400
,p_column_identifier=>'EJ'
,p_column_label=>'Force Single Carrier'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956768422708323)
,p_db_column_name=>'HUB_CARRIER_ID'
,p_display_order=>1410
,p_column_identifier=>'EK'
,p_column_label=>'Hub Carrier Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956834707708324)
,p_db_column_name=>'HUB_SERVICE_LEVEL'
,p_display_order=>1420
,p_column_identifier=>'EL'
,p_column_label=>'Hub Service Level'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1956944686708325)
,p_db_column_name=>'ORDER_GROUPING_ID'
,p_display_order=>1430
,p_column_identifier=>'EM'
,p_column_label=>'Order Grouping Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957075387708326)
,p_db_column_name=>'SHIP_BY_DATE_ERR'
,p_display_order=>1440
,p_column_identifier=>'EN'
,p_column_label=>'Ship By Date Err'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957110228708327)
,p_db_column_name=>'DEL_BY_DATE_ERR'
,p_display_order=>1450
,p_column_identifier=>'EO'
,p_column_label=>'Del By Date Err'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957255528708328)
,p_db_column_name=>'SHIP_BY_DATE_ERR_MSG'
,p_display_order=>1460
,p_column_identifier=>'EP'
,p_column_label=>'Ship By Date Err Msg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957320242708329)
,p_db_column_name=>'DEL_BY_DATE_ERR_MSG'
,p_display_order=>1470
,p_column_identifier=>'EQ'
,p_column_label=>'Del By Date Err Msg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957462953708330)
,p_db_column_name=>'ORDER_VALUE'
,p_display_order=>1480
,p_column_identifier=>'ER'
,p_column_label=>'Order Value'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957526693708331)
,p_db_column_name=>'EXPECTED_VOLUME'
,p_display_order=>1490
,p_column_identifier=>'ES'
,p_column_label=>'Expected Volume'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957677649708332)
,p_db_column_name=>'EXPECTED_WEIGHT'
,p_display_order=>1500
,p_column_identifier=>'ET'
,p_column_label=>'Expected Weight'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957760813708333)
,p_db_column_name=>'EXPECTED_VALUE'
,p_display_order=>1510
,p_column_identifier=>'EU'
,p_column_label=>'Expected Value'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957856540708334)
,p_db_column_name=>'TOD'
,p_display_order=>1520
,p_column_identifier=>'EV'
,p_column_label=>'Tod'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1957986604708335)
,p_db_column_name=>'TOD_PLACE'
,p_display_order=>1530
,p_column_identifier=>'EW'
,p_column_label=>'Tod Place'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958079600708336)
,p_db_column_name=>'LANGUAGE'
,p_display_order=>1540
,p_column_identifier=>'EX'
,p_column_label=>'Language'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958159500708337)
,p_db_column_name=>'SELLER_NAME'
,p_display_order=>1550
,p_column_identifier=>'EY'
,p_column_label=>'Seller Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958217783708338)
,p_db_column_name=>'SELLER_PHONE'
,p_display_order=>1560
,p_column_identifier=>'EZ'
,p_column_label=>'Seller Phone'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958323769708339)
,p_db_column_name=>'DOCUMENTATION_TEXT_1'
,p_display_order=>1570
,p_column_identifier=>'FA'
,p_column_label=>'Documentation Text 1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958453472708340)
,p_db_column_name=>'DOCUMENTATION_TEXT_2'
,p_display_order=>1580
,p_column_identifier=>'FB'
,p_column_label=>'Documentation Text 2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958571889708341)
,p_db_column_name=>'DOCUMENTATION_TEXT_3'
,p_display_order=>1590
,p_column_identifier=>'FC'
,p_column_label=>'Documentation Text 3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958649563708342)
,p_db_column_name=>'COD'
,p_display_order=>1600
,p_column_identifier=>'FD'
,p_column_label=>'Cod'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958747288708343)
,p_db_column_name=>'COD_VALUE'
,p_display_order=>1610
,p_column_identifier=>'FE'
,p_column_label=>'Cod Value'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958869212708344)
,p_db_column_name=>'COD_CURRENCY'
,p_display_order=>1620
,p_column_identifier=>'FF'
,p_column_label=>'Cod Currency'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1958931819708345)
,p_db_column_name=>'COD_TYPE'
,p_display_order=>1630
,p_column_identifier=>'FG'
,p_column_label=>'Cod Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959087773708346)
,p_db_column_name=>'VAT_NUMBER'
,p_display_order=>1640
,p_column_identifier=>'FH'
,p_column_label=>'Vat Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959103911708347)
,p_db_column_name=>'INV_VAT_NUMBER'
,p_display_order=>1650
,p_column_identifier=>'FI'
,p_column_label=>'Inv Vat Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959298496708348)
,p_db_column_name=>'HUB_VAT_NUMBER'
,p_display_order=>1660
,p_column_identifier=>'FJ'
,p_column_label=>'Hub Vat Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959306327708349)
,p_db_column_name=>'PRINT_INVOICE'
,p_display_order=>1670
,p_column_identifier=>'FK'
,p_column_label=>'Print Invoice'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959445591708350)
,p_db_column_name=>'INV_REFERENCE'
,p_display_order=>1680
,p_column_identifier=>'FL'
,p_column_label=>'Inv Reference'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959579757708301)
,p_db_column_name=>'INV_DSTAMP'
,p_display_order=>1690
,p_column_identifier=>'FM'
,p_column_label=>'Inv Dstamp'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959636593708302)
,p_db_column_name=>'INV_CURRENCY'
,p_display_order=>1700
,p_column_identifier=>'FN'
,p_column_label=>'Inv Currency'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959705747708303)
,p_db_column_name=>'LETTER_OF_CREDIT'
,p_display_order=>1710
,p_column_identifier=>'FO'
,p_column_label=>'Letter Of Credit'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959802731708304)
,p_db_column_name=>'PAYMENT_TERMS'
,p_display_order=>1720
,p_column_identifier=>'FP'
,p_column_label=>'Payment Terms'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1959988636708305)
,p_db_column_name=>'SUBTOTAL_1'
,p_display_order=>1730
,p_column_identifier=>'FQ'
,p_column_label=>'Subtotal 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960088538708306)
,p_db_column_name=>'SUBTOTAL_2'
,p_display_order=>1740
,p_column_identifier=>'FR'
,p_column_label=>'Subtotal 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960181434708307)
,p_db_column_name=>'SUBTOTAL_3'
,p_display_order=>1750
,p_column_identifier=>'FS'
,p_column_label=>'Subtotal 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960214651708308)
,p_db_column_name=>'SUBTOTAL_4'
,p_display_order=>1760
,p_column_identifier=>'FT'
,p_column_label=>'Subtotal 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960300248708309)
,p_db_column_name=>'FREIGHT_COST'
,p_display_order=>1770
,p_column_identifier=>'FU'
,p_column_label=>'Freight Cost'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960439183708310)
,p_db_column_name=>'FREIGHT_TERMS'
,p_display_order=>1780
,p_column_identifier=>'FV'
,p_column_label=>'Freight Terms'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960508187708311)
,p_db_column_name=>'INSURANCE_COST'
,p_display_order=>1790
,p_column_identifier=>'FW'
,p_column_label=>'Insurance Cost'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960611304708312)
,p_db_column_name=>'MISC_CHARGES'
,p_display_order=>1800
,p_column_identifier=>'FX'
,p_column_label=>'Misc Charges'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960762623708313)
,p_db_column_name=>'DISCOUNT'
,p_display_order=>1810
,p_column_identifier=>'FY'
,p_column_label=>'Discount'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960806656708314)
,p_db_column_name=>'OTHER_FEE'
,p_display_order=>1820
,p_column_identifier=>'FZ'
,p_column_label=>'Other Fee'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1960962873708315)
,p_db_column_name=>'INV_TOTAL_1'
,p_display_order=>1830
,p_column_identifier=>'GA'
,p_column_label=>'Inv Total 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961002844708316)
,p_db_column_name=>'INV_TOTAL_2'
,p_display_order=>1840
,p_column_identifier=>'GB'
,p_column_label=>'Inv Total 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961143663708317)
,p_db_column_name=>'INV_TOTAL_3'
,p_display_order=>1850
,p_column_identifier=>'GC'
,p_column_label=>'Inv Total 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961222992708318)
,p_db_column_name=>'INV_TOTAL_4'
,p_display_order=>1860
,p_column_identifier=>'GD'
,p_column_label=>'Inv Total 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961352557708319)
,p_db_column_name=>'TAX_RATE_1'
,p_display_order=>1870
,p_column_identifier=>'GE'
,p_column_label=>'Tax Rate 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961438067708320)
,p_db_column_name=>'TAX_BASIS_1'
,p_display_order=>1880
,p_column_identifier=>'GF'
,p_column_label=>'Tax Basis 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961518737708321)
,p_db_column_name=>'TAX_AMOUNT_1'
,p_display_order=>1890
,p_column_identifier=>'GG'
,p_column_label=>'Tax Amount 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961606758708322)
,p_db_column_name=>'TAX_RATE_2'
,p_display_order=>1900
,p_column_identifier=>'GH'
,p_column_label=>'Tax Rate 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961742088708323)
,p_db_column_name=>'TAX_BASIS_2'
,p_display_order=>1910
,p_column_identifier=>'GI'
,p_column_label=>'Tax Basis 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961894891708324)
,p_db_column_name=>'TAX_AMOUNT_2'
,p_display_order=>1920
,p_column_identifier=>'GJ'
,p_column_label=>'Tax Amount 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1961900162708325)
,p_db_column_name=>'TAX_RATE_3'
,p_display_order=>1930
,p_column_identifier=>'GK'
,p_column_label=>'Tax Rate 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962046937708326)
,p_db_column_name=>'TAX_BASIS_3'
,p_display_order=>1940
,p_column_identifier=>'GL'
,p_column_label=>'Tax Basis 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962111438708327)
,p_db_column_name=>'TAX_AMOUNT_3'
,p_display_order=>1950
,p_column_identifier=>'GM'
,p_column_label=>'Tax Amount 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962224410708328)
,p_db_column_name=>'TAX_RATE_4'
,p_display_order=>1960
,p_column_identifier=>'GN'
,p_column_label=>'Tax Rate 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962337659708329)
,p_db_column_name=>'TAX_BASIS_4'
,p_display_order=>1970
,p_column_identifier=>'GO'
,p_column_label=>'Tax Basis 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962444024708330)
,p_db_column_name=>'TAX_AMOUNT_4'
,p_display_order=>1980
,p_column_identifier=>'GP'
,p_column_label=>'Tax Amount 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962580420708331)
,p_db_column_name=>'TAX_RATE_5'
,p_display_order=>1990
,p_column_identifier=>'GQ'
,p_column_label=>'Tax Rate 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962620800708332)
,p_db_column_name=>'TAX_BASIS_5'
,p_display_order=>2000
,p_column_identifier=>'GR'
,p_column_label=>'Tax Basis 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962702094708333)
,p_db_column_name=>'TAX_AMOUNT_5'
,p_display_order=>2010
,p_column_identifier=>'GS'
,p_column_label=>'Tax Amount 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962862986708334)
,p_db_column_name=>'ORDER_REFERENCE'
,p_display_order=>2020
,p_column_identifier=>'GT'
,p_column_label=>'Order Reference'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1962936920708335)
,p_db_column_name=>'PROFORMA_INVOICE_NUM'
,p_display_order=>2030
,p_column_identifier=>'GU'
,p_column_label=>'Proforma Invoice Num'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963010888708336)
,p_db_column_name=>'TRAX_ID'
,p_display_order=>2040
,p_column_identifier=>'GV'
,p_column_label=>'Trax Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963102038708337)
,p_db_column_name=>'START_BY_DATE'
,p_display_order=>2050
,p_column_identifier=>'GW'
,p_column_label=>'Start By Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963297404708338)
,p_db_column_name=>'EXCLUDE_POSTCODE'
,p_display_order=>2060
,p_column_identifier=>'GX'
,p_column_label=>'Exclude Postcode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963309769708339)
,p_db_column_name=>'METAPACK_CARRIER_PRE'
,p_display_order=>2070
,p_column_identifier=>'GY'
,p_column_label=>'Metapack Carrier Pre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963462510708340)
,p_db_column_name=>'GROSS_WEIGHT'
,p_display_order=>2080
,p_column_identifier=>'GZ'
,p_column_label=>'Gross Weight'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963577983708341)
,p_db_column_name=>'ADDRESS3'
,p_display_order=>2090
,p_column_identifier=>'HA'
,p_column_label=>'Address3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963602722708342)
,p_db_column_name=>'ADDRESS4'
,p_display_order=>2100
,p_column_identifier=>'HB'
,p_column_label=>'Address4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963723058708343)
,p_db_column_name=>'INV_ADDRESS3'
,p_display_order=>2110
,p_column_identifier=>'HC'
,p_column_label=>'Inv Address3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963827645708344)
,p_db_column_name=>'INV_ADDRESS4'
,p_display_order=>2120
,p_column_identifier=>'HD'
,p_column_label=>'Inv Address4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1963990438708345)
,p_db_column_name=>'HUB_ADDRESS3'
,p_display_order=>2130
,p_column_identifier=>'HE'
,p_column_label=>'Hub Address3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1964071868708346)
,p_db_column_name=>'HUB_ADDRESS4'
,p_display_order=>2140
,p_column_identifier=>'HF'
,p_column_label=>'Hub Address4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1964118250708347)
,p_db_column_name=>'ADS_ID_STA'
,p_display_order=>2150
,p_column_identifier=>'HG'
,p_column_label=>'Ads Id Sta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1964294353708348)
,p_db_column_name=>'ADS_ID_BTA'
,p_display_order=>2160
,p_column_identifier=>'HH'
,p_column_label=>'Ads Id Bta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1964362605708349)
,p_db_column_name=>'ADS_ID_ADA'
,p_display_order=>2170
,p_column_identifier=>'HI'
,p_column_label=>'Ads Id Ada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1964406975708350)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>2180
,p_column_identifier=>'HJ'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1964534033708301)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>2190
,p_column_identifier=>'HK'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1964608527708302)
,p_db_column_name=>'LAST_UPDATED_BY'
,p_display_order=>2200
,p_column_identifier=>'HL'
,p_column_label=>'Last Updated By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1964713633708303)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>2210
,p_column_identifier=>'HM'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1964881696708304)
,p_db_column_name=>'CONCURRENCY_KEY'
,p_display_order=>2220
,p_column_identifier=>'HN'
,p_column_label=>'Concurrency Key'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2036801334709084)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'20369'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:ACT_ID:STATUS:DB_LINK:FROM_SITE_ID:TO_SITE_ID:CLIENT_ID:ORDER_ID:OWNER_ID:ORDER_TYPE:WORK_ORDER_TYPE:ORDER_STATUS:MOVE_TASK_STATUS:PRIORITY:REPACK:REPACK_LOC_ID:SHIP_DOCK:WORK_GROUP:CONSIGNMENT:DELIVERY_POINT:LOAD_SEQUENCE:CUSTOMER_ID:ORDER_DATE:S'
||'HIP_BY_DATE:DELIVER_BY_DATE:SHIPPED_DATE:DELIVERED_DSTAMP:SIGNATORY:PURCHASE_ORDER:CARRIER_ID:DISPATCH_METHOD:SERVICE_LEVEL:FASTEST_CARRIER:CHEAPEST_CARRIER:INV_ADDRESS_ID:INV_CONTACT:INV_CONTACT_PHONE:INV_CONTACT_MOBILE:INV_CONTACT_FAX:INV_CONTACT_E'
||'MAIL:INV_NAME:INV_ADDRESS1:INV_ADDRESS2:INV_TOWN:INV_COUNTY:INV_POSTCODE:INV_COUNTRY:INSTRUCTIONS:ORDER_VOLUME:ORDER_WEIGHT:CONTACT:CONTACT_PHONE:CONTACT_MOBILE:CONTACT_FAX:CONTACT_EMAIL:NAME:ADDRESS1:ADDRESS2:TOWN:COUNTY:POSTCODE:COUNTRY:ROUTE_PLANN'
||'ED:UPLOADED:UPLOADED_WS2PC_ID:UPLOADED_DSTAMP:UPLOADED_FILENAME:UPLOADED_VVIEW:UPLOADED_HEADER_KEY:PSFT_DMND_SRCE:PSFT_ORDER_ID:SITE_REPLEN:ORDER_ID_LINK:ALLOCATION_RUN:NO_SHIPMENT_EMAIL:CID_NUMBER:SID_NUMBER:LOCATION_NUMBER:FREIGHT_CHARGES:DISALLOW_'
||'MERGE_RULES:ORDER_SOURCE:EXPORT:NUM_LINES:HIGHEST_LABEL:USER_DEF_TYPE_1:USER_DEF_TYPE_2:USER_DEF_TYPE_3:USER_DEF_TYPE_4:USER_DEF_TYPE_5:USER_DEF_TYPE_6:USER_DEF_TYPE_7:USER_DEF_TYPE_8:USER_DEF_CHK_1:USER_DEF_CHK_2:USER_DEF_CHK_3:USER_DEF_CHK_4:USER_D'
||'EF_DATE_1:USER_DEF_DATE_2:USER_DEF_DATE_3:USER_DEF_DATE_4:USER_DEF_NUM_1:USER_DEF_NUM_2:USER_DEF_NUM_3:USER_DEF_NUM_4:USER_DEF_NOTE_1:USER_DEF_NOTE_2:CE_REASON_CODE:CE_REASON_NOTES:CE_ORDER_TYPE:CE_CUSTOMS_CUSTOMER:CE_EXCISE_CUSTOMER:CE_INSTRUCTIONS:'
||'ROUTE_ID:CROSS_DOCK_TO_SITE:WEB_SERVICE_ALLOC_IMMED:WEB_SERVICE_ALLOC_CLEAN:DISALLOW_SHORT_SHIP:UPLOADED_CUSTOMS:UPLOADED_LABOR:HUB_ADDRESS_ID:HUB_CONTACT:HUB_CONTACT_PHONE:HUB_CONTACT_MOBILE:HUB_CONTACT_FAX:HUB_CONTACT_EMAIL:HUB_NAME:HUB_ADDRESS1:HU'
||'B_ADDRESS2:HUB_TOWN:HUB_COUNTY:HUB_POSTCODE:HUB_COUNTRY:CANCEL_REASON_CODE:STAGE_ROUTE_ID:SINGLE_ORDER_SORTATION:ARCHIVED:CLOSURE_DATE:ORDER_CLOSED:TOTAL_REPACK_CONTAINERS:FORCE_SINGLE_CARRIER:HUB_CARRIER_ID:HUB_SERVICE_LEVEL:ORDER_GROUPING_ID:SHIP_B'
||'Y_DATE_ERR:DEL_BY_DATE_ERR:SHIP_BY_DATE_ERR_MSG:DEL_BY_DATE_ERR_MSG:ORDER_VALUE:EXPECTED_VOLUME:EXPECTED_WEIGHT:EXPECTED_VALUE:TOD:TOD_PLACE:LANGUAGE:SELLER_NAME:SELLER_PHONE:DOCUMENTATION_TEXT_1:DOCUMENTATION_TEXT_2:DOCUMENTATION_TEXT_3:COD:COD_VALU'
||'E:COD_CURRENCY:COD_TYPE:VAT_NUMBER:INV_VAT_NUMBER:HUB_VAT_NUMBER:PRINT_INVOICE:INV_REFERENCE:INV_DSTAMP:INV_CURRENCY:LETTER_OF_CREDIT:PAYMENT_TERMS:SUBTOTAL_1:SUBTOTAL_2:SUBTOTAL_3:SUBTOTAL_4:FREIGHT_COST:FREIGHT_TERMS:INSURANCE_COST:MISC_CHARGES:DIS'
||'COUNT:OTHER_FEE:INV_TOTAL_1:INV_TOTAL_2:INV_TOTAL_3:INV_TOTAL_4:TAX_RATE_1:TAX_BASIS_1:TAX_AMOUNT_1:TAX_RATE_2:TAX_BASIS_2:TAX_AMOUNT_2:TAX_RATE_3:TAX_BASIS_3:TAX_AMOUNT_3:TAX_RATE_4:TAX_BASIS_4:TAX_AMOUNT_4:TAX_RATE_5:TAX_BASIS_5:TAX_AMOUNT_5:ORDER_'
||'REFERENCE:PROFORMA_INVOICE_NUM:TRAX_ID:START_BY_DATE:EXCLUDE_POSTCODE:METAPACK_CARRIER_PRE:GROSS_WEIGHT:ADDRESS3:ADDRESS4:INV_ADDRESS3:INV_ADDRESS4:HUB_ADDRESS3:HUB_ADDRESS4:ADS_ID_STA:ADS_ID_BTA:ADS_ID_ADA:CREATED_BY:CREATION_DATE:LAST_UPDATED_BY:LA'
||'ST_UPDATE_DATE:CONCURRENCY_KEY'
);
wwv_flow_api.component_end;
end;
/
